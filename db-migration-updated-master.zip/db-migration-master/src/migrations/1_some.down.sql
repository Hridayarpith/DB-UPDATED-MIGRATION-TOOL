DROP TABLE account;
DROP TABLE accounts;