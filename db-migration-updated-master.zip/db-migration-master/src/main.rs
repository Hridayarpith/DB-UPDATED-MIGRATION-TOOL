use crate::migration::run_migration;
use std::time::Instant;

mod errors;
mod fs_helpers;
mod migration;
mod postgres_db;

fn main() {
    let now = Instant::now();
    match run_migration() {
        Ok(_) => println!("Migrations ran successfully"),
        Err(err) => eprintln!("Error during migration: {}", err),
    }
    let elapsed = now.elapsed();
    println!("Executed in: {:?}", elapsed);
}